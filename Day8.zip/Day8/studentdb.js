let students =[
    {regno:'2021ICT100',name:'Bavaruba',gender:'Female',age:24,course:'IT'},
    {regno:'2021ICT101',name:'Theyshine',gender:'Female',age:24,course:'CSC'},
    {regno:'2021ICT102',name:'Rajeev',gender:'Male',age:24,course:'AMC'},
    {regno:'2021ICT103',name:'Thaksihan',gender:'Male',age:23,course:'IT'},
    {regno:'2021ICT104',name:'Thanuharan',gender:'Male',age:23,course:'IT'},
    {regno:'2021ICT105',name:'Manimegalai',gender:'Female',age:24,course:'CSC'},
    {regno:'2021ICT106',name:'Vishnutharan',gender:'Male',age:23,course:'AMC'},
    {regno:'2021ICT107',name:'Nixon',gender:'Male',age:24,course:'IT'}
];

module.exports=students;