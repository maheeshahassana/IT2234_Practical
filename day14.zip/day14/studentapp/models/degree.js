const mongoose=require('mongoose')
const router = require('../routes/degreeRoute')

const degreeSchema=new mongoose.Schema({
    _id:{type:String,require:true},
    name:{type:String,require:true},
    credits:{type:Number,require:true},
    description:{type:String}
})

const degree=mongoose.model('degree',degreeSchema)
const webservice=new degree({
    _id:'it2234',
    name:'practical for webservice',
    credits:3,
    description:'built a rest api with nodejs technology'
})



webservice.save()
module.exports=degree