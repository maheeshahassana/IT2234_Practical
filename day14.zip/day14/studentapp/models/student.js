const mongoose=require('mongoose')
const router = require('../routes/degreeRoute')

const studentSchema=new mongoose.Schema({
    _id:{type:String,require:true},
    name:{type:String,require:true},
    credits:{type:Number,require:true},
    date_of_birth:{type:Date},
    gender:{type:Number},
    degreeId:{
        type:String,
        require:true,
        ref:'degree'
    }
})

const student=mongoose.model('student',studentSchema)
/const webservice=new student({
    _id:'it2234',
    name:'practical for webservice',
    credits:3,
   date_of_birth:'01-08-2020',
   gender:'male',
   degreeId:'fas2021'
})



webservice.save()*/
module.exports=student