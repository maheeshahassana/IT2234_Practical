const mongoose=require('mongoose')
const router = require('../routes/courseRoute')

const courseSchema=new mongoose.Schema({
    code:{type:String,require:true},
    name:{type:String,require:true},
    credits:{type:Number,require:true},
    description:{type:String}
})

const course=mongoose.model('courses',courseSchema)
const webservice=new course({
    code:'it2234',
    name:'practical for webservice',
    credits:3,
    description:'built a rest api with nodejs technology'
})



webservice.save()
module.exports=course