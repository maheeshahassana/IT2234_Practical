const express=require('express')
const router=express.Router()
const course=require('../models/course')

router.get('/',async(req,res)=>{
    try{
        const results=await course.find()
        if(results){
            res.status(200).json(results)
        }else{
            res.status(404).send('sorry,no data')
        }
    }catch(error){
        console.error(error);
        res.status(500).send("server error")
    }
})

router.get('/',async(req,res)=>{
    try{
        const id=req.params.id
        const results=await course.findById(id)
        if(results){
            res.status(200).json(results)
        }else{
            res.status(404).send('sorry,no data')
        }
    }catch(error){
        console.error(error);
        res.status(500).send("server error")
    }
})

router.get('/',async(req,res)=>{
    try{
        const id=req.params.cid
        const results=await course.find( {code:cid})
        if(results){
            res.status(200).json(results)
        }else{
            res.status(404).send('sorry,no data')
        }
    }catch(error){
        console.error(error);
        res.status(500).send("server error")
    }
})


module.exports=router