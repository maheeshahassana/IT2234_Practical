const mongoose=require('mongoose')

const courseSchema=new mongoose.Schema({
    code:{type:String},
    name:{type:String},
    credits:{type:Number},
    description:{type:String}
})

const course=mongoose.model('courses',courseSchema)
const webservice=new course({
    code:'it2234',
    name:'practical for webservice',
    credits:3,
    description:'built a rest api with nodejs technology'
})

webservice.save()
module.exports=course